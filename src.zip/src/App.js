import './App.css';
import MiniDrawer from './components/Delet';
import NavBar from './components/navbar/Navbar';


function App() {
  return (
    <div className="App">
    <NavBar />
    {/* <MiniDrawer/> */}
    {/* <Del/> */}
    </div>
  );
}

export default App;
