import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';

import {
  BrowserRouter as Router,
  Switch,
  Route,
  NavLink
} from "react-router-dom";
// import TechStats from '../technologyStats/TechStats';
import OverView from '../overview/OverView';
import EmployeeList from '../employeeList/EmployeeList';
import MiniDrawer from '../Delet';



export default function NavBar() {



  const useStyles = makeStyles((theme) => ({
    grow: {
      flexGrow: 1,
    },
    menuButton: {
      marginRight: theme.spacing(2),
    },
    title: {
      display: 'none',
      [theme.breakpoints.up('sm')]: {
        display: 'block',
      },
    },
    }));
  


  const classes = useStyles();



  return (
      <Router>
    <div className={classes.root}>
    <div className={classes.grow}>
      <AppBar position="static">
        <Toolbar style={{backgroundColor:'whitesmoke'}}>
        <Typography  className={classes.title} variant="h6" noWrap>
          <NavLink to="./" style={{textDecoration:'none', color:'black', fontSize: "large"}}>TY-TE Complete Bench Data</NavLink>
          </Typography>
        <div className={classes.grow} />
          <div className={classes.sectionDesktop}>
          </div>
        </Toolbar>
      </AppBar>
    </div>
   </div>
    <Switch>
      <Route exact path="/" component={EmployeeList} ></Route>
      <Route exact path="/techstats" component={MiniDrawer} ></Route>
      <Route exact path="/overView" component={OverView}></Route>

    </Switch>
   </Router>   
  );
}