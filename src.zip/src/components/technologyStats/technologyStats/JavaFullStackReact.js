import React from 'react'
import { Container } from "@material-ui/core";
import { useHistory } from "react-router";
import './Tech.css';
import myjson from "./angular.json";
import techjson from "./react.json";
import javajson from "./java.json";
import javafulljson from "./JavaFullStack.json";
import reactjson from "./JavaFullStack(React).json";

export default function JavaFullStackReact() {



    return (
      <div>
   <Container>
      <h3 style={{display:'flex', justifyContent:'center', margin:'30px',fontFamily:'font-family: SomeFont;'}}>Java Full-Stack With React Data Table</h3>
      <table className="table table-striped table-bordered"  id="techstat">
<thead class="">
  <tr>
    <th class="expand">Java Full Stack (React)</th>
    <th>1</th>
    <th>1 to 2</th>
    <th>2 to 3</th>
    <th>3 to 4</th>
    <th>4 to 5</th>
    <th>5 to 6</th>
    <th>6+</th>
 
</tr>
</thead>
<tbody>
  {reactjson.map((emp) => (
    <tr key={emp.JFSReact}>
       <td>{emp.JFSReact}</td>
      <td>{emp.greaterthanOne}</td>
      <td>{emp.OneToTwo}</td>
      <td>{emp.TwoToThree}</td>
      <td>{emp.ThreeToFour}</td>
      <td>{emp.FourToFive}</td>
      <td>{emp.FiveToSix}</td>
      <td>{emp.SixPlus}</td>
   </tr>
  ))}
</tbody>
</table>
</Container>
</div>
    )
  }

 

      
        