import React from 'react'
import axios from "axios";
import { Component } from "react";
import * as ReactDOM from "react-dom";
import { JsonToCsv, useJsonToCsv } from "react-json-csv";
import { Button, Container } from "@material-ui/core";
import { useHistory } from "react-router";
import myjson from './data.json';
import './Employee.css'
// import SearchBar from "material-ui-search-bar";



function EmpToCSV() {
    const filename = "TY-Development-Employee Details",
      fields = {
        No:"No",
        Empid: "Empid",
        FullName: "Full Name",
        Status: "Status",
        Paid: "Paid",
        PrimaryTechnology: "PrimaryTechnology",
        HighestQualification: "HighestQualification",
        Passout:"Passout",
        total: "Total Experience",
        relavent : 'Relavent Experience',
        projected : 'Project Experience',
        ContactNumbers:"ContactNumbers",
        OfficialEmail:"OfficialEmail",
        Dateofjoining: "Dateofjoining",
        Remark:"Remark"
        
      },
      style = {
        padding: "5px",
      },
  
      data = myjson,
      text = "Convert Json to Csv";
  
  
    <JsonToCsv
      data={data}
      filename={filename}
      fields={fields}
      style={style}
      text={text}
    />;
  
    const { saveAsCsv } = useJsonToCsv();
  
  
    return (
      <div class="text-left">
        <Button type="button" class="btn btn-success" onClick={(e) => saveAsCsv({ data, fields, filename })} style={{
        color:'white',backgroundColor:'rgb(35, 204, 124)', fontWeight:'bold'}}>
            Download</Button>
      </div>
    );
  }




export default function EmployeeList() {
    const history = useHistory();
    
      const handleClickTech=()=>{
        history.push({
          pathname:  "/techstats"
        })
      }
      const handleClickBench=()=>{
        history.push({
          pathname:  "/overview"
        })
      }
    return (
        <div style={{margin:'30px'}}>
      
        <span style={{display:'flex' , justifyContent:'flex-end'}}>
       
        <Button type="button" class="btn" onClick={handleClickBench}  style={{color:'white', marginRight:'30px', backgroundColor:'rgb(35, 204, 124)' , fontWeight:'bold'}}> Overview</Button>

        <Button type="button" class="btn" onClick={handleClickTech} style={{ color:'white',  marginRight:'30px',backgroundColor:'rgb(35, 204, 124)', fontWeight:'bold'}}> Technology Wise Stats</Button>

        </span>
          <br></br> 
          <div className="content-loader"> 
          
           <table id="emptable" className="table table-striped table-bordered shadow" style={{marginLeft:'5px'}}>
            <thead text-align="center">
            <tr>
            <th rowSpan="2" >EmpNo</th>
            <th rowSpan="2" >EmpId</th>
            <th rowSpan="2">FullName</th>
            <th rowSpan="3" >Status</th>
            <th rowSpan="2" >Paid</th>
            <th rowSpan="2" >Highest Qualification</th>
            <th rowSpan="2" >Primary Technology</th>
            <th rowSpan="2" >Passout</th>
            <th colSpan="3" style={{verticalAlign: 'middle', paddingLeft:'10px', paddingRight:'10px', textAlign: 'center', width: '50%'}}>Experience</th>
            <th rowSpan="2" >Contact Numbers</th>
            <th rowSpan="2" >OfficialEmail</th>
            <th rowSpan="2" >DateofJoining</th>
            <th rowSpan="2" >Remark</th>
          </tr>
        <tr>
            <th scope="col" >Total</th>
            <th scope="col">Relavent</th>
            <th scope="col">Projected</th>
        </tr>
            </thead>
            <tbody>
              {myjson.map((emp) => (
                <tr key={emp.Empid}>
                   <td>{emp.No}</td>
                  <td>{emp.Empid}</td>
                  <td>{emp.FullName}</td>
                  <td>
                  <select class="theme-construction">
                  <option id="ISIN3">Deployed</option>
                <option id="ISIN2">Terminated</option>
                <option id="ISIN4"> Resigned</option>
            </select>
                  </td>


                  <td  style={{padding:'15px'}} contenteditable='true'>
                  <select class="theme-construction">
                <option id="ISIN2">Yes</option>
                <option id="ISIN3">No</option>
            </select>
                  </td>

                  
                  <td  style={{padding:'15px'}}>
                  <select className="theme-construction">
                <option id="ISIN2">B.E / B.Tech</option>
                <option id="ISIN3">M.E / M.Tech</option>
                <option id="ISIN4"> B.C.A</option>
                <option id="ISIN4"> M.C.A</option>
                <option id="ISIN4"> B.COM</option>
                <option id="ISIN4"> ITI</option>
            </select>

                  </td>
                  <td style={{padding:'25px'}} contenteditable='true'>{emp.PrimaryTechnology}</td>

                  <td>{emp.Passout}</td>

                  <td>{emp.total}</td>
                  <td>{emp.relavent}</td>
                  <td>{emp.projected}</td>

                  
                  <td>{emp.ContactNumbers}</td>
                  <td>{emp.OfficialEmail}</td>
                  <td>{emp.DateofJoining}</td>
                  <td>{emp.Remark}</td>
                </tr>
              ))}
            </tbody>
          </table> 
          </div>
        <br></br>
        <div>
        <EmpToCSV/> 
        <br/>
        </div>
                
        </div>
    )
}

