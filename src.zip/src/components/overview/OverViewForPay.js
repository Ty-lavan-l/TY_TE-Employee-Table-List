import React, { Component } from "react";
import myjson from "./data2.json";
import "./OverView.css";

import { Container } from "@material-ui/core";


export default class OverViewForPay extends Component {
  render() {
    return (
     <Container>
          <table className="table table-striped table-bordered shadow" id="overview">
            <thead class="">
              <tr>
                <th>Category</th>
                <th>Pay</th>
                <th>No Pay</th>
                <th>Total</th>
             
             </tr>
            </thead>
            <tbody>
              {myjson.map((emp) => (
                <tr key={emp.Category}>
                   <td>{emp.Category}</td>
                  <td>{emp.Pay}</td>
                  <td>{emp.NoPay}</td>
                  <td>{emp.Total}</td>
               </tr>
              ))}
            </tbody>
          </table>
       </Container>
    );
  }
}
