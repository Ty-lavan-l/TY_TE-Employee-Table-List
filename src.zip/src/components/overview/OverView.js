import React from "react";
import "./OverView.css";
import myjson from "./data.json";
import {BrowserRouter as Router,
        } from 'react-router-dom';
// import OverViewForPay from "./OverViewForPay";
import { Container } from "@material-ui/core";
import myjson1 from "./data2.json";

export default function OverView() {


  return (
    <Router>
      <div>
          <Container>
        <h3 style={{display:'flex', justifyContent:'center', margin:'30px',fontFamily:'font-family: SomeFont;'}}>Test Yantra Employee Bench Staus</h3>
         
         <div class="row">
         <div class="col-md-6">
          <table className="table table-striped table-bordered shadow" id="overview">
            <thead>
              <tr>
                <th>Category</th>
                <th>0.6 to 1 Yr Experience</th>
                <th>1 + Yr Experience</th>
                <th>Total</th>
             
             </tr>
            </thead>
            <tbody>
              {myjson.map((emp) => (
                <tr key={emp.Category}>
                   <td>{emp.Category}</td>
                  <td>{emp.ZeroPontSixToOneExp}</td>
                  <td>{emp.OnePlusYearExp}</td>
                  <td>{emp.Total}</td>
               </tr>
              ))}
            </tbody>
          </table>
          </div>  


          <div class="col-md-6">
          <table className="table table-striped table-bordered shadow" id="overview">
            <thead class="">
              <tr>
                <th>Category</th>
                <th>Pay</th>
                <th>No Pay</th>
                <th>Total</th>
             
             </tr>
            </thead>
            <tbody>
              {myjson1.map((emp) => (
                <tr key={emp.Category}>
                   <td>{emp.Category}</td>
                  <td>{emp.Pay}</td>
                  <td>{emp.NoPay}</td>
                  <td>{emp.Total}</td>
               </tr>
              ))}
            </tbody>
          </table>
          </div>
          </div>
       </Container>
      </div>
      
      </Router>
  )
}

